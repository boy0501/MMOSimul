#pragma once
class Object
{
public:
	short  x, y;
};

