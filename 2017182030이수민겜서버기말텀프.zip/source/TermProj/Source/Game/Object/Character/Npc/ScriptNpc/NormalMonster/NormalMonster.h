#pragma once
#include "../ScriptNpc.h"
class NormalMonster : public ScriptNpc
{
public:
	NormalMonster(const char* scriptname, int n_id);
	virtual ~NormalMonster();

};

