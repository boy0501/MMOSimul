#pragma once
#include "../Npc.h"
class NormalNpc :public Npc
{
public:
	NormalNpc();
	virtual ~NormalNpc();
};

