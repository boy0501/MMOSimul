#pragma once
#include "../ScriptNpc.h"
class PlantMonster : public ScriptNpc
{
public:
	PlantMonster(const char* scriptname, int n_id);
	virtual ~PlantMonster();

};

