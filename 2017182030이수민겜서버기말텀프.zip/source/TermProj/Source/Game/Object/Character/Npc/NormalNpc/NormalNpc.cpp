#include <unordered_set>
#include "NormalNpc.h"
#include "../../../../Network/Network.h"
#include "../../Player/Player.h"
#include "../../Character.h"

using namespace std;


NormalNpc::NormalNpc()
	:Npc(TYPE::NOSCRIPTNPC)
{

}

NormalNpc::~NormalNpc()
{

}

