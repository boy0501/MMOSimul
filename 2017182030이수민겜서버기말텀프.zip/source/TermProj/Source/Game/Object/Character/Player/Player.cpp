#include "Player.h"
#include "../../../../DB/DB.h"
#include <iostream>

using namespace std;
Player::Player()
	:Character(TYPE::PLAYER)
	, _prev_size(0)
	, is_Healing(false)
	, attackTime(std::chrono::system_clock::now())
	, bufftype(0)
	, debufftype(0)
	, moveSaveCnt(0)
{
	hp = 30;
}

Player::~Player()
{
	closesocket(_socket);
}



void Player::recvPacket()
{
	ZeroMemory(&wsa_ex_recv.getWsaOver(), sizeof(wsa_ex_recv.getWsaOver()));
	wsa_ex_recv.getWsaBuf().buf = reinterpret_cast<char*>(wsa_ex_recv.getBuf() + _prev_size);
	wsa_ex_recv.getWsaBuf().len = BUFSIZE - _prev_size;

	DWORD flags = 0;
	int ret = WSARecv(_socket, &wsa_ex_recv.getWsaBuf(), 1, 0, &flags, &wsa_ex_recv.getWsaOver(), NULL);
	if (SOCKET_ERROR == ret) {
		int err = WSAGetLastError();
		if (ERROR_IO_PENDING != err)
		{
				
			//cout << "�÷��̾� ���ú� save" << "player name :" << name << endl;

			error_display(err);
		}
	}
}

void Player::sendPacket(void* packet, int bytes)
{
	WSA_OVER_EX* wsa_ex = new WSA_OVER_EX(CMD_SEND, bytes, packet);
	int ret = WSASend(_socket, &wsa_ex->getWsaBuf(), 1, 0, 0, &wsa_ex->getWsaOver(), NULL);
	if (SOCKET_ERROR == ret) {
		int err = WSAGetLastError();
		if (ERROR_IO_PENDING != err)
		{
			//cout << "�÷��̾� ���� save" << "player name :" << name << endl;

			error_display(err);
		}
	}
}

