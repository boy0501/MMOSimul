#pragma once

void TimerThread();