#pragma once
#include <WS2tcpip.h>

void WorkerThread();